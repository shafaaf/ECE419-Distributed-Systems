
public class Debug{
    public final static boolean debug = true;    

}
